// Fraction_2251120165_NguyenKhao.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include "ModeFrac.h"

int main()
{
    ModeFrac mF;
    int n;
    cout << "\nNhap n: "; cin >> n;
    mF.printNotOverN(n);
    mF.printNotOverOneHalf();
    mF.printNotSame();

    return 0;
}

